<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.3/css/dataTables.bootstrap4.min.css">
<body>
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
	<div class="col-md-12">
		<h3 style="text-align: center">Users List</h3>
		<div class="table-responsive">
                        <table id="adminuserstbl" class="table table-striped table-bordered">
                        <thead>
                          <tr>
                          	<th>S.No</th>
                            <th>First Name</th>
                            <th>Last Name</th>
                            <th>DOB</th>
                            <th>Countries</th> 
                            <th>State</th>
                            <th>City</th>
                            <th>Zip Code</th> 
                            <th>Action</th> 
                          </tr>
                        </thead>
                        <tbody>

                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                  	<tr>
	                  		<td><?php echo e($i); ?></td>
	                  		<td><?php echo e($user->firstname); ?></td>
	                  		<td><?php echo e($user->lastname); ?></td>
	                  		<td><?php echo e(date('d-m-Y',strtotime($user->dob))); ?></td>
	                  		<td><?php echo e($user->countryname); ?></td>
	                  		<td><?php echo e($user->statename); ?></td>
	                  		<td><?php echo e($user->cityname); ?></td>
	                  		<td><?php echo e($user->pincode); ?></td>
	                  		<td><a href="<?php echo e(url('editUser')); ?>/<?php echo e($user->id); ?>">Edit</a> | <a href="javascript:void(0);" onclick="deleteUser(<?php echo e($user->id); ?>)">Delete</a></td>

	                  	</tr>
	                  	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   
                        </tbody>
                      </table>
                      <div style="float:right;">
                      	<a href="<?php echo e(url('registration')); ?>">Add User</a>  &nbsp;&nbsp;&nbsp;<a href="<?php echo e(url('export')); ?>" >Export User</a>
                      	
                      </div>
 					
                    </div>
	</div>
	

</body>
</html>
<link rel="stylesheet" href="<?php echo e(asset('css/sweetalert2.min.css')); ?>">
  <script src="<?php echo e(asset('js/sweetalert2.all.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/jquery-3.5.1.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/jquery.dataTables.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/dataTables.bootstrap4.min.js')); ?>"></script>
<script type="text/javascript">
	function deleteUser(id)
	{
		 
        swal({
            title: "",
            text: "Are you sure? Do you want to delete this User?",
            type: "warning",
            showCancelButton: !0,
            confirmButtonText: "Yes",
            cancelButtonText: "No!",
            reverseButtons: !0
        }).then(function (e) {

            if (e.value === true) {
                var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');

                $.ajax({
                    type: 'POST',
                    url: "<?php echo e(url('deleteUser')); ?>",
                    data: {_token: CSRF_TOKEN,id:id},
                    dataType: 'JSON',
                    success: function (results) {
                      
                        if (results.code == 200) {
                            swal("Done!", results.message, "success");
                             
                           window.location.reload();
                        } else {
                            swal("Error!", results.message, "error");
                             
                        }
                    }
                });

            } else {
                e.dismiss;
            }

        }, function (dismiss) {
            return false;
        })
	}
</script>
 <?php /**PATH D:\xampp\htdocs\laravel\interviewtask\resources\views/viewusers.blade.php ENDPATH**/ ?>