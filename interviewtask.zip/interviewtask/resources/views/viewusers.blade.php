<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.3/css/dataTables.bootstrap4.min.css">
<body>
	<meta name="csrf-token" content="{{ csrf_token() }}">
	<div class="col-md-12">
		<h3 style="text-align: center">Users List</h3>
		<div class="table-responsive">
                        <table id="adminuserstbl" class="table table-striped table-bordered">
                        <thead>
                          <tr>
                          	<th>S.No</th>
                            <th>First Name</th>
                            <th>Last Name</th>
                            <th>DOB</th>
                            <th>Countries</th> 
                            <th>State</th>
                            <th>City</th>
                            <th>Zip Code</th> 
                            <th>Action</th> 
                          </tr>
                        </thead>
                        <tbody>

                        @foreach($users as $user)
	                  	<tr>
	                  		<td>{{$i}}</td>
	                  		<td>{{$user->firstname}}</td>
	                  		<td>{{$user->lastname}}</td>
	                  		<td>{{date('d-m-Y',strtotime($user->dob))}}</td>
	                  		<td>{{$user->countryname}}</td>
	                  		<td>{{$user->statename}}</td>
	                  		<td>{{$user->cityname}}</td>
	                  		<td>{{$user->pincode}}</td>
	                  		<td><a href="{{url('editUser')}}/{{$user->id}}">Edit</a> | <a href="javascript:void(0);" onclick="deleteUser({{$user->id}})">Delete</a></td>

	                  	</tr>
	                  	@endforeach
                   
                        </tbody>
                      </table>
                      <div style="float:right;">
                      	<a href="{{url('registration')}}">Add User</a>  &nbsp;&nbsp;&nbsp;<a href="{{url('export')}}" >Export User</a>
                      	
                      </div>
 					
                    </div>
	</div>
	

</body>
</html>
<link rel="stylesheet" href="{{asset('css/sweetalert2.min.css')}}">
  <script src="{{asset('js/sweetalert2.all.min.js')}}"></script>
<script type="text/javascript" src="{{asset('js/jquery-3.5.1.js')}}"></script>
<script type="text/javascript" src="{{asset('js/jquery.dataTables.min.js')}}"></script>
<script type="text/javascript" src="{{asset('js/dataTables.bootstrap4.min.js')}}"></script>
<script type="text/javascript">
	function deleteUser(id)
	{
		 
        swal({
            title: "",
            text: "Are you sure? Do you want to delete this User?",
            type: "warning",
            showCancelButton: !0,
            confirmButtonText: "Yes",
            cancelButtonText: "No!",
            reverseButtons: !0
        }).then(function (e) {

            if (e.value === true) {
                var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');

                $.ajax({
                    type: 'POST',
                    url: "{{url('deleteUser')}}",
                    data: {_token: CSRF_TOKEN,id:id},
                    dataType: 'JSON',
                    success: function (results) {
                      
                        if (results.code == 200) {
                            swal("Done!", results.message, "success");
                             
                           window.location.reload();
                        } else {
                            swal("Error!", results.message, "error");
                             
                        }
                    }
                });

            } else {
                e.dismiss;
            }

        }, function (dismiss) {
            return false;
        })
	}
</script>
 