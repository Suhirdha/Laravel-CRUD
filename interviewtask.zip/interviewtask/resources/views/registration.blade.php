<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<style type="text/css">
.error{
	color: red;
}
	* {
  margin: 0
}

.container {
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  height: 100vh;
  background-color: #6699cc;
}

.container h1 {
  color: white;
  font-family: sans-serif;
  margin: 20px;
}

.registartion-form {
  display: flex;
  justify-content: center;
  align-items: center;
  width: 600px;
  color: rgb(255, 255, 255);
  font-size: 18px;
  font-family: sans-serif;
  background-color: #154a68;
  padding: 20px;
}

.registartion-form input,
.registartion-form select,
.registartion-form textarea {
  border: none;
  padding: 5px;
  margin-top: 10px;
  font-family: sans-serif;
}

.registartion-form input:focus,
.registartion-form textarea:focus {
  box-shadow: 3px 3px 10px rgb(228, 228, 228), -3px -3px 10px rgb(224, 224, 224);
}

.registartion-form .submit {
  width: 100%;
  padding: 8px 0;
  font-size: 20px;
  color: rgb(44, 44, 44);
  background-color: #ffffff;
  border-radius: 5px;
}

.registartion-form .submit:hover {
  box-shadow: 3px 3px 6px rgb(255, 214, 176);
}
</style>
<body>
<div class="container">
  <h1>HTML registration form with varification</h1>
  <form name="registration" id="registration" class="registartion-form">
  	  @csrf
    <table>
      <tr>
        <td><label for="name">First Name:</label></td>
        <td><input type="text" name="firstname" id="firstname" placeholder="your name"></td>
      </tr>
      <tr>
      	 <tr>
        <td><label for="name">Last Name:</label></td>
        <td><input type="text" name="lastname" id="lastname" placeholder="your name"></td>
      </tr>
      <tr>
        <td><label for="email">DOB:</label></td>
        <td><input type="date" name="dob" id="dob" placeholder="your dob"></td>
      </tr>
       <tr>
        <td><label for="email">No of Children:</label></td>
        <td><input type="number" name="noof_children" id="noof_children" placeholder="no of children"></td>
      </tr>
       <tr>
        <td><label for="about">Address 1:</label></td>
        <td><textarea name="address1" id="address1" placeholder="Write about yourself..."></textarea></td>
      </tr>
        <tr>
        <td><label for="about">Address 2:</label></td>
        <td><textarea name="address2" id="address2" placeholder="Write about yourself..."></textarea></td>
      </tr>
      <tr>
        <td><label for="language">Countries</label></td>
        <td>
          <select name="countries" id="countries">
            <option value="">Select Countries</option>
              @foreach($countries as $country)
              <option value="{{$country->id}}" >{{$country->name}}</option>
              @endforeach
          </select>
        </td>
      </tr>
      <tr>
        <td><label for="language">State</label></td>
        <td>
          <select name="state" id="state">
              <option value="">Select State</option>
          </select>
        </td>
      </tr>
       <tr>
        <td><label for="language">City</label></td>
        <td>
          <select name="city" id="city">
          	 <option value="">Select City</option>
             
          </select>
        </td>
      </tr>
      <tr>
        <td><label for="zipcode">Zip Code:</label></td>
        <td><input type="number" name="zipcode" id="zipcode"></td>
      </tr>
     
        <tr>
        <td><label for="about">Comments:</label></td>
        <td><textarea name="comments" id="comments" placeholder="Write about yourself..."></textarea></td>
      </tr>
      <tr>
        <td colspan="2"><input type="submit" class="submit" value="Register" /></td>
      </tr>
    </table>
  </form>
</div>
</body>
</html>
<script type="text/javascript" src="{{asset('js/jquery.min.js')}}"></script>
<script type="text/javascript" src="{{asset('js/jquery.validate.min.js')}}"></script>
<link rel="stylesheet" href="{{asset('css/sweetalert2.min.css')}}">
<script src="{{asset('js/sweetalert2.all.min.js')}}"></script>
<script>
$(document).ready(function(){

	$("#countries").on("change",function(){
		var countryid = $(this).val();
		$.ajax({
          url: "{{url('getStates')}}"+"/"+countryid,
          type: 'get',
          data: {},
          dataType: 'json', 
          success: function (response) {
          var selectdata = '<option value="">Select States</option>'; 
          	 var count = Object.keys(response).length;
            
              $.each(response, function(i, value) 
              {
              	selectdata +='<option value="'+value.id+'">'+value.name+'</option>';
              });
           
           $("#state").html(selectdata);
               
             }  
          }); 
	});
	$("#state").on("change",function(){
		var stateid = $(this).val();
		$.ajax({
          url: "{{url('getCities')}}"+"/"+stateid,
          type: 'get',
          data: {},
          dataType: 'json', 
          success: function (response) {
          var selectdata = '<option value="">Select Cities</option>'; 
          	 var count = Object.keys(response).length;
            
              $.each(response, function(i, value) 
              {
              	selectdata +='<option value="'+value.id+'">'+value.name+'</option>';
              });
           
           $("#city").html(selectdata);
               
             }  
          }); 
	});
	$("#registration").validate({
   rules:{
    firstname : {
      required: true,
    },
   
    lastname:{
      required: true,
      
    }, 
    dob:{
      required: true,
      
    },
    noof_children: {
      required: true,
      maxlength:1,
      minlength:1,
    }, 
    countries: {
      required: true,
    },
    state:{
      required:true,
    }, 
    city:{
      required:true,
    },
    zipcode:{
      required:true,
    },   
   
  },
     messages:{
      firstname : {required:"Please enter First Name"},
      
      lastname:{required:"Please Enter Last Name",
                     },
      
      dob:{required:"Please Enter DOB",
            },
      noof_children : {required:"Please enter No of Children",
  						minlength:"Please enter only one digit",
  						maxlength:"Please enter only one digit"},
      country:{required:"Please Select Countries" },
      state:{required:"Please Select State" },
      city:{required:"Please Select city" },
      zipcode:{required:"Please Select Zipcode" },
      
 
      }
});

	$("#registration").submit(function () {
  if($("#registration").valid()){
     var formData = new FormData(this);
      $.ajax({
          url: "{{url('addUsers')}}",
          type: 'POST',
          data: formData,
          dataType: 'json',
          async: false,
          cache: false,
          contentType: false,
          processData: false,
          /*beforeSend: function()
          {
              $("#loader").show();
          },
          complete: function()
          {
           $("#loader").hide();
          },*/
          success: function (response) {
           
               if(response.code == 200)
               {
                //swal("success",data.message,"");
                swal({
                    title: "Done",
                    text: response.message,
                    type: "success",
                    confirmButtonClass: "btn-danger",
                    confirmButtonText: "OK",
                    closeOnConfirm: false,
                }).then(function(){
                                      window.location.reload();
                                  })
               }
               else{
                 swal({
                      title: "",
                      text: response.message,
                      type: "error",
                      confirmButtonClass: "btn-danger",
                      confirmButtonText: "Ok"
                    }, function(isConfirm){
                      if (isConfirm) {
                        location.reload();
                    } 
                    });
               }
          },
          error: function(data){
            

               swal({
                      title: "",
                      text:data.message,
                      type: "error",
                      confirmButtonClass: "btn-danger",
                      confirmButtonText: "Ok"
                    }, function(isConfirm){
                      if (isConfirm) {
                        location.reload();
                    } 
                    });
          }
      });
      
return false;
  }
     
  });
});
</script>