<?php

namespace App\Http\Controllers;
 
use Illuminate\Http\Request;
use App\Models\Countries;
use App\Models\States;
use App\Models\Cities;
use App\Models\Users;
use Excel;
use App\Exports\UsersExport;
use DB;
class CommonController extends Controller
{
    //
    public function registration()
    {
    	$countries = Countries::all();
    	return view('registration',compact('countries'));
    }
    public function getStates($id)
    {
    	$states = States::where('country_id',$id)->get();
    	return $states;
    }
    public function getCities($id)
    {
    	$cities = Cities::where('state_id',$id)->get();
    	return $cities;
    }
    public function addUsers(Request $request)
    {
    	try{
    		$users = new Users(); 
	        
        $users->firstname = $request->firstname; 
        $users->lastname = $request->lastname;
        $users->dob = $request->dob;
        $users->address1 = $request->address1; 
        $users->address2 = $request->address2;
        $users->no_of_children = $request->noof_children;
        $users->country = $request->countries; 
        $users->state = $request->state;
        $users->city = $request->city;
        $users->pincode= $request->zipcode;
        $users->comments = $request->comments;
        $users->save(); 
	 	return ["code"=>200,"message"=>'Users has been added Successfully'];
     } 
    catch(Exception $e) 
    {
      return ["code"=>400,"message"=>"Problem Occured while adding user"];
    }

    }
    public function viewUsers()
    {
    	$users = Users::join('tbl_countries','tbl_countries.id','=','sample.country')->join('tbl_states','tbl_states.id','=','sample.state')->join('tbl_cities','tbl_cities.id','=','sample.city')->select('tbl_countries.name as countryname','sample.*','tbl_states.name as statename','tbl_cities.name as cityname')->get();
    	return view('viewusers',compact('users'))->with('i','1');
    }
    public function editUser($id)
    {
    	$countries = Countries::all();

    	$user = Users::where('id',$id)->first();
    	$states= States::where('country_id',$user->country)->get();
    	$cities= Cities::where('state_id',$user->state)->get();
    	return view('edituser',compact('user','countries','states','cities'));
    }
    public function updateUsers(Request $request)
    {
    	try{
    	
    	DB::table('sample')->where('id',$request->userid)->update([
    			"firstname" => $request->firstname, 
        "lastname" =>$request->lastname,
        "dob" =>$request->dob,
        "address1"=> $request->address1,
        "address2"=> $request->address2,
        "no_of_children" =>$request->noof_children,
        "country" =>$request->countries,
        "state" =>$request->state,
        "city" =>$request->city,
        "pincode"=> $request->zipcode,
        "comments"=> $request->comments,
    ]);
        
        
	 	return ["code"=>200,"message"=>'Users has been added Successfully'];
     } 
    catch(Exception $e) 
    {
      return ["code"=>400,"message"=>"Problem Occured while adding user"];
    }

    }
    public function deleteUser(Request $request)
    {
    	try{
    	
    	 $delete = Users::find($request->id)->delete();
        
        
	 	return ["code"=>200,"message"=>'Users has been deleted Successfully'];
     } 
    catch(Exception $e) 
    {
      return ["code"=>400,"message"=>"Problem Occured while deleting user"];
    }
    }
    public function export() 
    {
        return Excel::download(new UsersExport, 'users.xlsx');
    }
}
