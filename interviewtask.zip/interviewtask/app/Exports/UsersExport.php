<?php

namespace App\Exports;

use App\Models\Users;
use Maatwebsite\Excel\Concerns\FromCollection;

class UsersExport implements FromCollection
{
    /**
    * @return \Illuminate\Support\Collection
    */
    public function collection()
    {
        return Users::join('tbl_countries','tbl_countries.id','=','sample.country')->join('tbl_states','tbl_states.id','=','sample.state')->join('tbl_cities','tbl_cities.id','=','sample.city')->select('tbl_countries.name as countryname','sample.firstname','sample.lastname','sample.dob','sample.address1','sample.address2','sample.pincode','sample.comments','tbl_states.name as statename','tbl_cities.name as cityname')->get();
    }
}
