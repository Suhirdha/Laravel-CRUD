<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Users extends Model
{
    use HasFactory;
    protected $table = 'sample';
    protected $primaryKey = 'id';
    public $timestamps = false;

    protected $fillable = [
       	  'firstname',
          'lastname', 
          'dob',
          'address1',
          'address2',
          'no_of_children',
          'country',
          'state',
          'city',
          'pincode',
          'comments'
    ];
}
