<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\CommonController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', [CommonController::class, 'viewUsers']);
Route::get('registration',  [CommonController::class, 'registration']);
Route::get('getStates/{id}',  [CommonController::class, 'getStates']);
Route::get('getCities/{id}',  [CommonController::class, 'getCities']);
Route::post('addUsers',  [CommonController::class, 'addUsers']);
Route::get('viewUsers',  [CommonController::class, 'viewUsers']);
Route::get('editUser/{id}',  [CommonController::class, 'editUser']);
Route::post('updateUsers',  [CommonController::class, 'updateUsers']);
Route::post('deleteUser',  [CommonController::class, 'deleteUser']);
Route::get('export',  [CommonController::class, 'export']);

